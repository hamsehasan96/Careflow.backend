// Clean app.js with refactored paths and ready for Render deployment
